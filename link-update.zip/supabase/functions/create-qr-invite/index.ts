import { serve } from "https://deno.land/std@0.224.0/http/server.ts";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2";
import { nanoid } from "https://esm.sh/nanoid@4";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
};

serve(async (req) => {
  if (req.method === "OPTIONS") {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const { inviterId, ttlHours = 24, maxUses = 1 } = await req.json();

    if (!inviterId) {
      return new Response(JSON.stringify({ error: "inviterId required" }), {
        status: 400, headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    const supabase = createClient(
      Deno.env.get("SUPABASE_URL")!,
      Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!,
      { auth: { persistSession: false } }
    );

    const token = nanoid(24);
    const expiresAt = new Date(Date.now() + ttlHours * 3600_000).toISOString();

    const { data, error } = await supabase.from("guest_invites").insert({
      inviter_id: inviterId,
      token,
      expires_at: expiresAt,
      max_uses: maxUses,
    }).select("id, token, expires_at").single();

    if (error) throw error;

    const baseUrl = Deno.env.get("PUBLIC_APP_URL")!;
    const inviteUrl = `${baseUrl.replace(/\/$/, "")}/guest/${data.token}`;

    return new Response(JSON.stringify({ inviteUrl, token: data.token, expiresAt: data.expires_at }), {
      headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  } catch (e) {
    console.error("create-qr-invite error:", e);
    return new Response(JSON.stringify({ error: e?.message || "Internal error" }), {
      status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  }
});
